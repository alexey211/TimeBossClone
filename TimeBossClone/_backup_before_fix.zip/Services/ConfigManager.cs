using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using TimeBossClone.Models;

namespace TimeBossClone.Services;

public class ConfigManager
{
    public static readonly string DataDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "TimeBossClone");

    private static readonly string ConfigPath = Path.Combine(DataDir, "config.json");

    private AppConfig _config = new();

    public AppConfig Config => _config;

    public ConfigManager()
    {
        Directory.CreateDirectory(DataDir);
        Load();
    }

    public void Load()
    {
        if (!File.Exists(ConfigPath)) { _config = new AppConfig(); return; }
        var json = File.ReadAllText(ConfigPath);
        _config = JsonSerializer.Deserialize<AppConfig>(json) ?? new AppConfig();
    }

    public void Save()
    {
        var json = JsonSerializer.Serialize(_config, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(ConfigPath, json);
    }

    public UsageRecord LoadTodayUsage() => LoadUsage(DateTime.Today);

    public UsageRecord LoadUsage(DateTime date)
    {
        var path = GetUsagePath(date);
        if (!File.Exists(path))
            return new UsageRecord { Date = date.ToString("yyyy-MM-dd") };
        var json = File.ReadAllText(path);
        return JsonSerializer.Deserialize<UsageRecord>(json)
            ?? new UsageRecord { Date = date.ToString("yyyy-MM-dd") };
    }

    public void SaveTodayUsage(UsageRecord record)
    {
        var json = JsonSerializer.Serialize(record, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(GetUsagePath(DateTime.Today), json);
    }

    private static string GetUsagePath(DateTime date) =>
        Path.Combine(DataDir, $"usage_{date:yyyy-MM-dd}.json");

    public bool VerifyPassword(string password) =>
        HashPassword(password) == _config.PasswordHash;

    public void SetPassword(string password) =>
        _config.PasswordHash = HashPassword(password);

    public static string HashPassword(string password)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(password));
        return Convert.ToHexString(bytes);
    }

    public int GetTodayLimitMinutes() =>
        DateTime.Today.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday
            ? _config.WeekendLimitMinutes
            : _config.WeekdayLimitMinutes;
}
