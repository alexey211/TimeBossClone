using Microsoft.Win32;

namespace TimeBossClone.Services;

public static class SystemPolicyService
{
    private const string PolicyKey = @"Software\Microsoft\Windows\CurrentVersion\Policies\System";

    public static void ApplyLockPolicies(bool blockTaskManager, bool blockRegistry)
    {
        SetPolicy("DisableTaskMgr", blockTaskManager ? 1 : null);
        SetPolicy("DisableRegistryTools", blockRegistry ? 1 : null);
    }

    public static void RemoveLockPolicies()
    {
        SetPolicy("DisableTaskMgr", null);
        SetPolicy("DisableRegistryTools", null);
    }

    private static void SetPolicy(string valueName, int? value)
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(PolicyKey, writable: true)
                ?? Registry.CurrentUser.CreateSubKey(PolicyKey);
            if (value.HasValue)
                key.SetValue(valueName, value.Value, RegistryValueKind.DWord);
            else
                key.DeleteValue(valueName, throwOnMissingValue: false);
        }
        catch { }
    }

    public static List<string> GetLocalUserAccounts()
    {
        var systemDirs = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            { "Public", "Default", "Default User", "All Users" };

        var systemDrive = Environment.GetEnvironmentVariable("SystemDrive") ?? "C:";
        var usersDir = Path.Combine(systemDrive, "Users");

        try
        {
            return Directory.GetDirectories(usersDir)
                .Select(Path.GetFileName)
                .Where(n => n is not null && !systemDirs.Contains(n))
                .Select(n => n!)
                .OrderBy(n => n)
                .ToList();
        }
        catch
        {
            return [Environment.UserName];
        }
    }
}
