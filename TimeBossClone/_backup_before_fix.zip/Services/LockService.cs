using System.Runtime.InteropServices;

namespace TimeBossClone.Services;

public static class LockService
{
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool LockWorkStation();

    public static void Lock() => LockWorkStation();
}
