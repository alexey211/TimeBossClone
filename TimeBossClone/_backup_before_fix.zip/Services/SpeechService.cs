using System.Speech.Synthesis;

namespace TimeBossClone.Services;

public class SpeechService : IDisposable
{
    private readonly SpeechSynthesizer _synth;
    private readonly bool _hasRussian;

    public SpeechService()
    {
        _synth = new SpeechSynthesizer();
        _synth.Volume = 100;
        _synth.Rate = -1;

        var ruVoice = _synth.GetInstalledVoices()
            .FirstOrDefault(v => v.VoiceInfo.Culture.TwoLetterISOLanguageName == "ru");

        if (ruVoice != null)
        {
            _synth.SelectVoice(ruVoice.VoiceInfo.Name);
            _hasRussian = true;
        }
    }

    public void SayWarning(int minutesLeft)
    {
        string text = _hasRussian
            ? minutesLeft == 10
                ? "Внимание! Осталось десять минут."
                : "Внимание! Осталось пять минут."
            : minutesLeft == 10
                ? "Warning! Ten minutes remaining."
                : "Warning! Five minutes remaining.";

        try { _synth.SpeakAsync(text); }
        catch { /* TTS не критична */ }
    }

    public void Dispose() => _synth.Dispose();
}
