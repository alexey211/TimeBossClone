using TimeBossClone.Models;

namespace TimeBossClone.Services;

public class TimeTracker : IDisposable
{
    private readonly ConfigManager _configManager;
    private readonly System.Windows.Forms.Timer _timer;
    private UsageRecord _today;
    private DateTime _currentDate;
    private int _saveCounter;
    private int _requestCheckCounter;

    public event Action<int>? OnWarning;
    public event Action? OnLimitReached;
    public event Action? OnUnlocked;
    public event Action<int, int, int>? OnTick; // usedMinutes, limitMinutes, remainingSeconds

    public TimeTracker(ConfigManager configManager)
    {
        _configManager = configManager;
        _today = configManager.LoadTodayUsage();
        _currentDate = DateTime.Today;

        _timer = new System.Windows.Forms.Timer { Interval = 1000 };
        _timer.Tick += Tick;
    }

    public int UsedSeconds => _today.UsedSeconds;
    public bool IsLocked => _today.IsLocked;

    public int ExtraMinutes
    {
        get => _today.ExtraMinutes;
        set { _today.ExtraMinutes = value; _configManager.SaveTodayUsage(_today); }
    }

    public int GetLimitMinutes() => _configManager.GetTodayLimitMinutes() + _today.ExtraMinutes;

    public int GetRemainingSeconds() => Math.Max(0, GetLimitMinutes() * 60 - _today.UsedSeconds);

    public void Start()
    {
        if (_today.IsLocked) OnLimitReached?.Invoke();
        _timer.Start();
    }

    public void Stop() => _timer.Stop();

    private void Tick(object? sender, EventArgs e)
    {
        if (DateTime.Today != _currentDate)
        {
            _currentDate = DateTime.Today;
            _today = _configManager.LoadTodayUsage();
        }

        _requestCheckCounter++;
        if (_requestCheckCounter >= 15)
        {
            _requestCheckCounter = 0;
            int added = RequestService.ConsumeAddedMinutes(Environment.UserName);
            if (added > 0)
            {
                _today.ExtraMinutes += added;
                _today.IsLocked = false;
                _configManager.SaveTodayUsage(_today);
                OnUnlocked?.Invoke();
                return;
            }
        }

        if (_today.IsLocked) return;

        _today.UsedSeconds++;

        int limitMinutes = GetLimitMinutes();
        int remainingSeconds = limitMinutes * 60 - _today.UsedSeconds;
        int remainingMinutes = remainingSeconds / 60;

        foreach (int warn in new[] { 10, 5 })
        {
            if (remainingMinutes == warn && remainingSeconds % 60 == 0
                && !_today.WarnedAtMinutes.Contains(warn))
            {
                _today.WarnedAtMinutes.Add(warn);
                OnWarning?.Invoke(warn);
            }
        }

        if (_today.UsedSeconds >= limitMinutes * 60)
        {
            _today.IsLocked = true;
            _configManager.SaveTodayUsage(_today);
            OnLimitReached?.Invoke();
            return;
        }

        _saveCounter++;
        if (_saveCounter >= 30)
        {
            _saveCounter = 0;
            _configManager.SaveTodayUsage(_today);
        }

        OnTick?.Invoke(_today.UsedSeconds / 60, limitMinutes, Math.Max(0, remainingSeconds));
    }

    public void Unlock()
    {
        _today.IsLocked = false;
        _configManager.SaveTodayUsage(_today);
        OnUnlocked?.Invoke();
    }

    public void Dispose()
    {
        _configManager.SaveTodayUsage(_today);
        _timer.Dispose();
    }
}
