namespace TimeBossClone.Services;

public static class RequestService
{
    private static readonly string RequestsDir = Path.Combine(
        Environment.GetEnvironmentVariable("PUBLIC") ?? @"C:\Users\Public",
        "TimeBossClone", "requests");

    public static void EnsureDirectory() => Directory.CreateDirectory(RequestsDir);

    public static void SendAddTime(string targetUser, int minutes)
    {
        EnsureDirectory();
        var fileName = $"{targetUser}_{Guid.NewGuid():N}.req";
        File.WriteAllText(Path.Combine(RequestsDir, fileName), minutes.ToString());
    }

    public static int ConsumeAddedMinutes(string currentUser)
    {
        try
        {
            EnsureDirectory();
            int total = 0;
            foreach (var file in Directory.GetFiles(RequestsDir, $"{currentUser}_*.req"))
            {
                try
                {
                    if (int.TryParse(File.ReadAllText(file).Trim(), out int mins))
                        total += mins;
                    File.Delete(file);
                }
                catch { }
            }
            return total;
        }
        catch { return 0; }
    }
}
