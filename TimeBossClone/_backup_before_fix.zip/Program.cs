using TimeBossClone.Forms;

namespace TimeBossClone;

static class Program
{
    [STAThread]
    static void Main()
    {
        using var mutex = new Mutex(true, "TimeBossClone_SingleInstance", out bool isNew);
        if (!isNew)
        {
            MessageBox.Show("TimeBoss уже запущен.", "TimeBoss",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new TrayApplicationContext());
    }
}
