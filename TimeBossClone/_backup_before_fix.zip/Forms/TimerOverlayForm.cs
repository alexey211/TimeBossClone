namespace TimeBossClone.Forms;

public class TimerOverlayForm : Form
{
    private readonly Label _label;

    public TimerOverlayForm()
    {
        FormBorderStyle = FormBorderStyle.None;
        TopMost = true;
        ShowInTaskbar = false;
        BackColor = Color.FromArgb(20, 20, 20);
        Opacity = 0.82;
        Size = new Size(164, 44);
        StartPosition = FormStartPosition.Manual;

        RepositionToBottomRight();

        _label = new Label
        {
            ForeColor = Color.Lime,
            BackColor = Color.Transparent,
            Font = new Font("Consolas", 17f, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleCenter,
            Dock = DockStyle.Fill,
            Text = "--:--"
        };
        Controls.Add(_label);
    }

    public void UpdateRemaining(int remainingSeconds)
    {
        if (IsDisposed || !IsHandleCreated) return;
        if (InvokeRequired) { Invoke(() => UpdateRemaining(remainingSeconds)); return; }

        int h = remainingSeconds / 3600;
        int m = remainingSeconds % 3600 / 60;
        int s = remainingSeconds % 60;
        _label.Text = h > 0 ? $"{h}:{m:D2}:{s:D2}" : $"{m:D2}:{s:D2}";
        _label.ForeColor = remainingSeconds <= 300 ? Color.OrangeRed : Color.Lime;

        RepositionToBottomRight();
    }

    private void RepositionToBottomRight()
    {
        var area = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
        Location = new Point(area.Right - Width - 10, area.Bottom - Height - 10);
    }

    protected override bool ShowWithoutActivation => true;

    protected override void WndProc(ref Message m)
    {
        const int WM_NCHITTEST = 0x84;
        const int HTTRANSPARENT = -1;
        if (m.Msg == WM_NCHITTEST) { m.Result = (IntPtr)HTTRANSPARENT; return; }
        base.WndProc(ref m);
    }
}
