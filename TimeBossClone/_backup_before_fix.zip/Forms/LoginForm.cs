using TimeBossClone.Services;

namespace TimeBossClone.Forms;

public class LoginForm : Form
{
    private readonly bool _isSetup;
    private readonly ConfigManager _config;
    private readonly TextBox _passwordBox;
    private TextBox? _confirmBox;
    private readonly Label _errorLabel;

    public LoginForm(bool isSetup, ConfigManager config)
    {
        _isSetup = isSetup;
        _config = config;

        Text = isSetup ? "Первый запуск — Создание пароля" : "Вход в панель управления";
        Size = new Size(340, isSetup ? 240 : 185);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterScreen;
        MaximizeBox = false;
        MinimizeBox = false;

        Controls.Add(new Label
        {
            Text = isSetup ? "Придумайте пароль для родителя:" : "Введите пароль:",
            Location = new Point(20, 20),
            AutoSize = true
        });

        _passwordBox = new TextBox
        {
            UseSystemPasswordChar = true,
            Location = new Point(20, 45),
            Width = 285
        };
        _passwordBox.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) TrySubmit(); };
        Controls.Add(_passwordBox);

        int nextY = 75;

        if (isSetup)
        {
            Controls.Add(new Label
            {
                Text = "Повторите пароль:",
                Location = new Point(20, nextY),
                AutoSize = true
            });
            nextY += 25;

            _confirmBox = new TextBox
            {
                UseSystemPasswordChar = true,
                Location = new Point(20, nextY),
                Width = 285
            };
            _confirmBox.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) TrySubmit(); };
            Controls.Add(_confirmBox);
            nextY += 35;
        }

        _errorLabel = new Label
        {
            ForeColor = Color.Crimson,
            Location = new Point(20, nextY),
            Size = new Size(285, 20)
        };
        Controls.Add(_errorLabel);
        nextY += 28;

        var btnOk = new Button
        {
            Text = isSetup ? "Создать" : "Войти",
            Location = new Point(20, nextY),
            Width = 130,
            Height = 32
        };
        btnOk.Click += (_, _) => TrySubmit();
        Controls.Add(btnOk);

        var btnCancel = new Button
        {
            Text = "Отмена",
            Location = new Point(175, nextY),
            Width = 130,
            Height = 32,
            DialogResult = DialogResult.Cancel
        };
        Controls.Add(btnCancel);

        AcceptButton = btnOk;
        CancelButton = btnCancel;
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        _passwordBox.Focus();
    }

    private void TrySubmit()
    {
        _errorLabel.Text = string.Empty;

        if (_isSetup)
        {
            if (_passwordBox.Text.Length < 4)
            {
                _errorLabel.Text = "Минимум 4 символа";
                return;
            }
            if (_passwordBox.Text != _confirmBox!.Text)
            {
                _errorLabel.Text = "Пароли не совпадают";
                _confirmBox.Clear();
                _confirmBox.Focus();
                return;
            }
            _config.SetPassword(_passwordBox.Text);
            _config.Save();
            DialogResult = DialogResult.OK;
        }
        else
        {
            if (_config.VerifyPassword(_passwordBox.Text))
            {
                DialogResult = DialogResult.OK;
            }
            else
            {
                _errorLabel.Text = "Неверный пароль";
                _passwordBox.Clear();
                _passwordBox.Focus();
            }
        }
    }
}
