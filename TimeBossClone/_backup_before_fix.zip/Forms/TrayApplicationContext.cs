using Microsoft.Win32;
using TimeBossClone.Services;

namespace TimeBossClone.Forms;

public class TrayApplicationContext : ApplicationContext
{
    private readonly NotifyIcon _trayIcon = null!;
    private readonly ConfigManager _configManager;
    private readonly TimeTracker _tracker = null!;
    private readonly SpeechService _speech;
    private TimerOverlayForm? _overlay;
    private readonly bool _shouldMonitor;

    public TrayApplicationContext()
    {
        _configManager = new ConfigManager();
        _speech = new SpeechService();

        if (_configManager.Config.IsFirstRun)
        {
            using var setup = new LoginForm(isSetup: true, _configManager);
            if (setup.ShowDialog() != DialogResult.OK)
            {
                Application.Exit();
                return;
            }
            _configManager.Config.IsFirstRun = false;
            _configManager.Save();
        }

        var monitored = _configManager.Config.MonitoredAccounts;
        _shouldMonitor = monitored.Count == 0
            || monitored.Contains(Environment.UserName, StringComparer.OrdinalIgnoreCase);

        _tracker = new TimeTracker(_configManager);

        _tracker.OnWarning += minutesLeft =>
        {
            _speech.SayWarning(minutesLeft);
            _trayIcon?.ShowBalloonTip(6000, "TimeBoss",
                $"Осталось {minutesLeft} минут!", ToolTipIcon.Warning);
        };

        _tracker.OnLimitReached += () =>
        {
            if (!_shouldMonitor) return;
            _trayIcon?.ShowBalloonTip(3000, "TimeBoss", "Время вышло!", ToolTipIcon.Error);
            _overlay?.Hide();
            SystemPolicyService.ApplyLockPolicies(
                _configManager.Config.BlockTaskManager,
                _configManager.Config.BlockRegistryEditor);
            Task.Delay(2500).ContinueWith(_ => LockService.Lock());
        };

        _tracker.OnUnlocked += () =>
        {
            SystemPolicyService.RemoveLockPolicies();
            _overlay?.Show();
        };

        _tracker.OnTick += (usedMin, limitMin, remSec) =>
        {
            int rem = limitMin - usedMin;
            string tip = $"TimeBoss — осталось {rem} мин";
            if (tip.Length > 63) tip = tip[..63];
            if (_trayIcon != null) _trayIcon.Text = tip;
            if (_shouldMonitor) _overlay?.UpdateRemaining(remSec);
        };

        var menu = new ContextMenuStrip();
        menu.Items.Add("Настройки (родитель)", null, OpenAdmin);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Завершить (родитель)", null, ExitApp);

        _trayIcon = new NotifyIcon
        {
            Icon = SystemIcons.Shield,
            Text = "TimeBoss",
            Visible = true,
            ContextMenuStrip = menu
        };
        _trayIcon.DoubleClick += OpenAdmin;

        _tracker.Start();

        SystemEvents.SessionSwitch += OnSessionSwitch;

        if (_shouldMonitor)
        {
            _overlay = new TimerOverlayForm();
            if (!_tracker.IsLocked)
            {
                _overlay.UpdateRemaining(_tracker.GetRemainingSeconds());
                _overlay.Show();
            }
            else
            {
                SystemPolicyService.ApplyLockPolicies(
                    _configManager.Config.BlockTaskManager,
                    _configManager.Config.BlockRegistryEditor);
            }
        }
    }

    private void OnSessionSwitch(object sender, SessionSwitchEventArgs e)
    {
        if (e.Reason == SessionSwitchReason.SessionUnlock && _tracker.IsLocked)
        {
            SystemPolicyService.ApplyLockPolicies(
                _configManager.Config.BlockTaskManager,
                _configManager.Config.BlockRegistryEditor);
            Task.Delay(500).ContinueWith(_ => LockService.Lock());
        }
    }

    private void OpenAdmin(object? sender, EventArgs e)
    {
        using var login = new LoginForm(isSetup: false, _configManager);
        if (login.ShowDialog() != DialogResult.OK) return;
        using var admin = new AdminForm(_configManager, _tracker);
        admin.ShowDialog();
    }

    private void ExitApp(object? sender, EventArgs e)
    {
        using var login = new LoginForm(isSetup: false, _configManager);
        if (login.ShowDialog() != DialogResult.OK) return;

        SystemPolicyService.RemoveLockPolicies();
        _overlay?.Close();
        _trayIcon.Visible = false;
        _tracker.Dispose();
        _speech.Dispose();
        Application.Exit();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            SystemEvents.SessionSwitch -= OnSessionSwitch;
            _overlay?.Dispose();
            _trayIcon?.Dispose();
            _tracker?.Dispose();
            _speech?.Dispose();
        }
        base.Dispose(disposing);
    }
}
