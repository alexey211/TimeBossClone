namespace TimeBossClone.Models;

public class UsageRecord
{
    public string Date { get; set; } = string.Empty;
    public int UsedSeconds { get; set; } = 0;
    public bool IsLocked { get; set; } = false;
    public int ExtraMinutes { get; set; } = 0;
    public List<int> WarnedAtMinutes { get; set; } = new();
}
